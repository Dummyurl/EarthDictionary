We do not accept pull requests.

Found a bug? Please [create an issue](https://github.com/googlevr/gvr-android-sdk/issues)!
